from constraint import *
import time

"""
M. Enes ŞİMŞEK
CS404-Homework 2
Akari Game Solver with Python Constraint
"""
def areAllLit(board, whites, r, c):
    # Every cell being lit by a bulb (horizontal + vertical cells have exactly one bulb)
    for cell in whites:
        are_cells_lit = []
        x = cell[0]
        y = cell[1]
        # look for empty cells in the same row
        while y < c:
            if board[x][y] is "w":
                are_cells_lit.append((x, y))
                y += 1
            else:
                break
        y = cell[1] - 1
        while y >= 0:
            if board[x][y] is "w":
                are_cells_lit.append((x, y))
                y -= 1
            else:
                break

        y = cell[1]  # reset y
        x = cell[0] + 1
        # look for empty cells in the same column
        while x < r:
            if board[x][y] is "w":
                are_cells_lit.append((x, y))
                x += 1
            else:
                break
        x = cell[0] - 1
        while x >= 0:
            if board[x][y] is "w":
                are_cells_lit.append((x, y))
                x -= 1
            else:
                break
        are_cells_lit.sort()
        return are_cells_lit


def adjacency_finder(board, numbers, r, c):

    number_adjacency = []
    # Finding adjacent cells.
    for n in numbers:
        adjacency_list = []
        if n[0] - 1 >= 0: # Top adjacent cell
            adjacent_cell = (n[0] - 1, n[1])
            if board[adjacent_cell[0]][adjacent_cell[1]] == 'w':
                adjacency_list.append(adjacent_cell)
        if n[0] + 1 < r:  # Bottom adjacent cell
            adjacent_cell = (n[0] + 1, n[1])
            if board[adjacent_cell[0]][adjacent_cell[1]] == 'w':
                adjacency_list.append(adjacent_cell)
        if n[1] - 1 >= 0:  # Left adjacent cell
            adjacent_cell = (n[0], n[1] - 1)
            if board[adjacent_cell[0]][adjacent_cell[1]] == 'w':
                adjacency_list.append(adjacent_cell)
        if n[1] + 1 < c:  # Right adjacent cell
            adjacent_cell = (n[0], n[1] + 1)
            if board[adjacent_cell[0]][adjacent_cell[1]] == 'w':
                adjacency_list.append(adjacent_cell)

        number_adjacency.append(adjacency_list)

    return number_adjacency


def solver(board):

    akari_game = Problem()
    bulbOrLight = [0, 1]  # 1: bulb, 0: lighted
    r = len(board)
    c = len(board[0])

    numbers = []
    obstacles = []
    whites = []
    count = 0
    for y in board:
        for u in range(c):
            if y[u] == 'w':
                whites.append((count, u))
            elif y[u] == 'b':
                obstacles.append((count, u))
            elif 0 <= int(y[u]) <= 4:
                numbers.append((count, u))
        count = count + 1

    # I have all the coordinates of board as tuples stored in arrays.

    akari_game.addVariables(numbers, ["num0", "num1", "num2", "num3", "num4"]) # I did not add constraints for naming. It means that, for example, 1 may map to num2
    # however, since I do not need the names in my solution, there is no need to add a constraint for that. I added them to remove confusion
    akari_game.addVariables(whites, bulbOrLight)  # either a bulb or lighted already.
    akari_game.addVariables(obstacles, 'b')  # obstacles will have the value 'b'

    number_adjacency = adjacency_finder(board, numbers, r, c)

    for n in range(len(numbers)):
        numberInBoard = board[numbers[n][0]][numbers[n][1]]  # looks like useless but since I do not use dictionary here, this is necessary
        akari_game.addConstraint(ExactSumConstraint(numberInBoard), number_adjacency[n])

    intermediate_rows = []
    count = 0
    in_array = []

    for y in board:
        for u in range(c):
            if y[u] == 'w':
                in_array.append((count, u))
            else:
                if in_array:
                    intermediate_rows.append(in_array)
                in_array = []
        if in_array:
            intermediate_rows.append(in_array)
        in_array = []
        # print(intermediate_rows)
        count = count + 1

    intermediate_columns = []
    count1 = 0
    in_array_2 = []

    board_transpose = [*zip(*board)] # getting the transpose of the original board to find intermediate_columns as well.

    for p in board_transpose:
        for v in range(r):
            if p[v] == 'w':
                in_array_2.append((v, count1))
            else:
                if in_array_2:
                    intermediate_columns.append(in_array_2)
                in_array_2 = []
        if in_array_2:
            intermediate_columns.append(in_array_2)
        in_array_2 = []
        # print(intermediate_columns)
        count1 = count1 + 1

    for column in intermediate_columns:
        akari_game.addConstraint(MaxSumConstraint(1), column)
    for row in intermediate_rows:
        akari_game.addConstraint(MaxSumConstraint(1), row)


    # We should also make sure that every cells is lighted before we find the solution.
    are_cells_lit = areAllLit(board, whites, r, c)
    akari_game.addConstraint(MinSumConstraint(1), are_cells_lit)

    return akari_game.getSolution()


if __name__ == '__main__':

    # just change any of the boards name to "board" and try the algorithm.
    # Lamps are represented with 'L' sign whereas white cells are 'w', black cells are 'b' and number cells are 'num0,...,num4'

    board3 = [['w', 'w', 'b', 'w', 2],
              ['w', 'b', 'w', 'w', 'w'],
              ['w', 'w', 'w', 'w', 'b'],
              [0, 'w', 'w', 'b', 'w']]

    board = [[0, 'w', 'w', 'w', 'w', 'w', 'b'],
              ['w', 'w', 'w', 'w', 0, 'w', 'w'],
              ['w', 1, 'b', 'w', 3, 'w', 'w'],
              ['w', 'w', 'w', 'b', 'w', 'w', 'w'],
              ['w', 'w', 1, 'w', 3, 1, 'w'],
              ['w', 'w', 'b', 'w', 'w', 'w', 'w'],
              ['b', 'w', 'w', 'w', 'w', 'w', 1]]

    board2 = [['w', 'w', 'w', 'w', 'w', 'w', 'b'],
             ['w', 'w', 4, 'w', 'w', 'w', 'w'],
             [0, 'w', 'w', 'w', 1, 'b', 'w'],
             ['w', 'w', 'w', 1, 'w', 'w', 'w'],
             ['w', 'b', 1, 'w', 'w', 'w', 'b'],
             ['w', 'w', 'w', 'w', 'b', 'w', 'w'],
             [1, 'w', 'w', 'w', 'w', 'w', 'w']]

    start = time.time()

    solution = solver(board)

    if solution is None:
        print("No solution for the Akari game found in THIS board. Please try another board.")
    else:
        for key in solution:
            if solution[key] == 1:
                board[key[0]][key[1]] = 'L'
            """
            elif solution[key] == 0:
                board[key[0]][key[1]] = 'w' # CHANGE 'w' TO ANYTHING YOU LIKE FOR USER VIEWING CONVENIENCE
            """
        print("At least one solution found:")
        for n in board:
            print(n)

        finish = time.time()

        print("Time passed is", finish - start)
